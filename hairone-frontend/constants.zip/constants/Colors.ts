export default {
  primary: '#f59e0b',

  background: '#0f172a',

  card: '#1e293b',

  text: '#ffffff',

  textMuted: '#94a3b8',

  border: '#334155',

  success: '#10b981',
  
  error: '#ef4444',
};